# MarketBuzzr Landing (React + Vite)

A minimal, static landing page scaffolded for your placeholder homepage.
It approximates the provided artwork and uses the exported image as the hero mockup.

## Quick start

```bash
yarn
yarn dev
```

Build & preview:

```bash
yarn build
yarn preview
```

All images live under `public/images/`. Replace `MarketBuzzr@2x.png` with your final asset to update the hero.
Typography uses Inter (Google Fonts). Styles are vanilla CSS in `src/styles.css` for simplicity.

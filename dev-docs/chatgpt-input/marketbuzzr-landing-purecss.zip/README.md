# MarketBuzzr Landing — Pure CSS/SVG

A static React + Vite homepage built from first principles (no big PNG hero).
The dashboard at the top is a styled container with a tiny inline SVG chart.

## Run

```bash
corepack enable
yarn install
yarn dev
```

Build:
```bash
yarn build
yarn preview
```
